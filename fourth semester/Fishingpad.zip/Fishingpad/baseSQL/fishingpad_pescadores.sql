-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: fishingpad
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pescadores`
--

DROP TABLE IF EXISTS `pescadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pescadores` (
  `id_pescadores` int NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `peso_en_gramos` varchar(50) DEFAULT NULL,
  `valor_en_MXN` int DEFAULT NULL,
  `id_envio` int NOT NULL,
  KEY `id_envio` (`id_envio`),
  KEY `fk_pescadores_usuario` (`id_pescadores`),
  CONSTRAINT `fk_pescadores_usuario` FOREIGN KEY (`id_pescadores`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `pescadores_ibfk_1` FOREIGN KEY (`id_envio`) REFERENCES `envios` (`id_envio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pescadores`
--

LOCK TABLES `pescadores` WRITE;
/*!40000 ALTER TABLE `pescadores` DISABLE KEYS */;
INSERT INTO `pescadores` VALUES (4,'tilapia','2000',500,2),(4,'sardina','1000',200,1),(1,'vagre','1500',300,3),(4,'tilapia','900',99,4),(4,'tilapia','900',99,4),(4,'tilapia','900',99,4),(4,'tilapia','9',99,5),(4,'tilapia','9',99,6),(8,'Bacalao','1500',300,2),(1,'tilapia','3500',600,3);
/*!40000 ALTER TABLE `pescadores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-24 17:52:46
