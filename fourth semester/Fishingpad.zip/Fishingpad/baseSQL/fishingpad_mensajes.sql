-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: fishingpad
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mensajes`
--

DROP TABLE IF EXISTS `mensajes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mensajes` (
  `id_mensaje` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `contenido` text NOT NULL,
  `fecha_envio` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `receptor` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_mensaje`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `mensajes_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensajes`
--

LOCK TABLES `mensajes` WRITE;
/*!40000 ALTER TABLE `mensajes` DISABLE KEYS */;
INSERT INTO `mensajes` VALUES (2,6,'hello cff','2025-04-14 03:29:03',NULL),(3,6,'.','2025-04-14 03:40:53','Joselo Ramirez'),(4,6,'hola ¿como estas?','2025-04-14 03:46:15','ariel'),(5,8,'waos','2025-04-14 03:49:12','Luis Erre'),(6,8,'prueba uno','2025-04-14 03:52:29','Luis Erre'),(7,6,'prueva 1.1','2025-04-14 03:58:35','8'),(8,8,'waos','2025-04-14 04:02:17','6'),(9,8,'xd','2025-04-14 04:14:22','6'),(10,6,'esto realmente funciona? xd','2025-04-14 04:37:10','8'),(11,8,'ci ;)','2025-04-14 04:37:21','6'),(12,6,'drop prueba','2025-04-14 04:57:29','8'),(13,6,'cff','2025-04-14 05:24:01','7'),(14,6,'drop prueva 1.1 inicializacion','2025-04-14 05:24:14','7'),(15,7,'receptor n7 cmd','2025-04-14 05:25:16','6'),(16,7,'prueba \"\"no funcional','2025-04-14 05:25:52','6'),(17,6,'persona 1 funcional','2025-04-14 05:26:06','7'),(18,6,'ok ahora que?','2025-04-27 05:29:14','8'),(19,6,'prueba roll pad 1','2025-04-27 05:29:28','8'),(20,8,'erizo','2025-04-28 14:12:10','6'),(21,6,'plasa zesamo','2025-04-28 14:12:27','8'),(22,8,'hellow','2025-04-28 14:17:02','6'),(23,8,'ERIZO','2025-05-13 15:26:40','6'),(24,6,'cuka','2025-05-13 15:27:03','8'),(25,8,'doña noemi','2025-05-13 15:27:18','6'),(26,6,'pati laballe','2025-05-13 15:27:36','8'),(27,19,'Q hace erizo','2025-05-27 13:28:19','8'),(28,8,'HOLA ','2025-06-02 14:19:55','6'),(29,22,'hola','2025-06-02 18:51:39','8'),(30,2,'hola','2025-06-02 19:47:39','8');
/*!40000 ALTER TABLE `mensajes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-24 17:52:19
