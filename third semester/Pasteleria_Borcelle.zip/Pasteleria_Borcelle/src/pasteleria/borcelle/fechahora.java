/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pasteleria.borcelle;

import java.util.Calendar;

/**
 *
 * @author karen
 */
public class fechahora {
    static Calendar Hora = Calendar.getInstance();
    static Calendar Fecha = Calendar.getInstance();
        
   public static void main(String[] args){
        int hora, minutos, segundos, dia,mes,anho;
        String FechaActual, HoraActual;
        
        hora = Hora.get(Calendar.HOUR_OF_DAY);
        minutos = Hora.get(Calendar.MINUTE);
        segundos = Hora.get(Calendar.SECOND);
        dia = Fecha.get(Calendar.DATE);
        mes = Fecha.get(Calendar.MONTH);
        anho = Fecha.get(Calendar.YEAR);
        
        HoraActual= (hora-1) + ":" + minutos + ":" + segundos;
        FechaActual= dia + "/" + (mes+1) + "/" + anho;
        System.out.println("Fecha actual es:"+  FechaActual + ", Hora Actual es: " + HoraActual);
             
         
       
    }
    String HoraActual;
    String FechaActual;
    
}
