/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leerenvoz;
import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

public class TestFreeTTS {
    public static void main(String[] args) {
        // Establecer la propiedad del sistema para las voces
        System.setProperty("freetts.voices",
            "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");

        // Obtener el administrador de voces
        VoiceManager voiceManager = VoiceManager.getInstance();

        // Listar las voces disponibles
        Voice[] voices = voiceManager.getVoices();
        System.out.println("Voces disponibles:");
        for (Voice voice : voices) {
            System.out.println(" - " + voice.getName());
        }

        // Obtener la voz 'kevin16'
        Voice voice = voiceManager.getVoice("kevin16");
        if (voice != null) {
            voice.allocate();
            voice.speak("pasame el cigarro.");
            voice.deallocate();
        } else {
            System.out.println("No se encontró la voz: kevin16");
        }
    }
}
